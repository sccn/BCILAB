/**
 * Extensions which enhance {@link matlabcontrol.MatlabProxy}'s capabilities.
 * 
 * @since 4.0.0
 */
package matlabcontrol.extensions;