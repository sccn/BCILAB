% BIPOLAR_COLORMAP
%
% Files
%   bipolar                - bipolar: symmetric/diverging/bipolar colormap, with neutral central color.
%   colormap_investigation - Find a bipolar colormap, linear in grayscale, close to a template map.
%   colormap_optimization  - colormap_optimisation: minimally modify colormap to satisfy constraints.
%   colormap_visualization - colormap_visualization: produce visualisations for evaluating colormaps.
