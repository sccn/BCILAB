#!/bin/bash  
perl -pi -w -e 's/union\(/union_bc\(/g;' *.m
perl -pi -w -e 's/=union\(/=union_bc\(/g;' *.m
perl -pi -w -e 's/= union\(/= union_bc\(/g;' *.m
perl -pi -w -e 's/ = union\(/ = union_bc\(/g;' *.m
perl -pi -w -e 's/intersect\(/intersect_bc\(/g;' *.m
perl -pi -w -e 's/=intersect\(/=intersect_bc\(/g;' *.m
perl -pi -w -e 's/= intersect\(/= intersect_bc\(/g;' *.m
perl -pi -w -e 's/ = intersect\(/ = intersect_bc\(/g;' *.m
perl -pi -w -e 's/setdiff\(/setdiff_bc\(/g;' *.m
perl -pi -w -e 's/=setdiff\(/=setdiff_bc\(/g;' *.m
perl -pi -w -e 's/= setdiff\(/= setdiff_bc\(/g;' *.m
perl -pi -w -e 's/ = setdiff\(/ = setdiff_bc\(/g;' *.m
perl -pi -w -e 's/unique\(/unique_bc\(/g;' *.m
perl -pi -w -e 's/=unique\(/=unique_bc\(/g;' *.m
perl -pi -w -e 's/= unique\(/= unique_bc\(/g;' *.m
perl -pi -w -e 's/ = unique\(/ = unique_bc\(/g;' *.m
perl -pi -w -e 's/ismember\(/ismember_bc\(/g;' *.m
perl -pi -w -e 's/=ismember\(/=ismember_bc\(/g;' *.m
perl -pi -w -e 's/= ismember\(/= ismember_bc\(/g;' *.m
perl -pi -w -e 's/ = ismember\(/ = ismember_bc\(/g;' *.m

perl -pi -w -e 's/union\(/union_bc\(/g;' */*.m
perl -pi -w -e 's/=union\(/=union_bc\(/g;' */*.m
perl -pi -w -e 's/= union\(/= union_bc\(/g;' */*.m
perl -pi -w -e 's/ = union\(/ = union_bc\(/g;' */*.m
perl -pi -w -e 's/intersect\(/intersect_bc\(/g;' */*.m
perl -pi -w -e 's/=intersect\(/=intersect_bc\(/g;' */*.m
perl -pi -w -e 's/= intersect\(/= intersect_bc\(/g;' */*.m
perl -pi -w -e 's/ = intersect\(/ = intersect_bc\(/g;' */*.m
perl -pi -w -e 's/setdiff\(/setdiff_bc\(/g;' */*.m
perl -pi -w -e 's/=setdiff\(/=setdiff_bc\(/g;' */*.m
perl -pi -w -e 's/= setdiff\(/= setdiff_bc\(/g;' */*.m
perl -pi -w -e 's/ = setdiff\(/ = setdiff_bc\(/g;' */*.m
perl -pi -w -e 's/unique\(/unique_bc\(/g;' */*.m
perl -pi -w -e 's/=unique\(/=unique_bc\(/g;' */*.m
perl -pi -w -e 's/= unique\(/= unique_bc\(/g;' */*.m
perl -pi -w -e 's/ = unique\(/ = unique_bc\(/g;' */*.m
perl -pi -w -e 's/ismember\(/ismember_bc\(/g;' */*.m
perl -pi -w -e 's/=ismember\(/=ismember_bc\(/g;' */*.m
perl -pi -w -e 's/= ismember\(/= ismember_bc\(/g;' */*.m
perl -pi -w -e 's/ = ismember\(/ = ismember_bc\(/g;' */*.m

perl -pi -w -e 's/union\(/union_bc\(/g;' */*/*.m
perl -pi -w -e 's/=union\(/=union_bc\(/g;' */*/*.m
perl -pi -w -e 's/= union\(/= union_bc\(/g;' */*/*.m
perl -pi -w -e 's/ = union\(/ = union_bc\(/g;' */*/*.m
perl -pi -w -e 's/intersect\(/intersect_bc\(/g;' */*/*.m
perl -pi -w -e 's/=intersect\(/=intersect_bc\(/g;' */*/*.m
perl -pi -w -e 's/= intersect\(/= intersect_bc\(/g;' */*/*.m
perl -pi -w -e 's/ = intersect\(/ = intersect_bc\(/g;' */*/*.m
perl -pi -w -e 's/setdiff\(/setdiff_bc\(/g;' */*/*.m
perl -pi -w -e 's/=setdiff\(/=setdiff_bc\(/g;' */*/*.m
perl -pi -w -e 's/= setdiff\(/= setdiff_bc\(/g;' */*/*.m
perl -pi -w -e 's/ = setdiff\(/ = setdiff_bc\(/g;' */*/*.m
perl -pi -w -e 's/unique\(/unique_bc\(/g;' */*/*.m
perl -pi -w -e 's/=unique\(/=unique_bc\(/g;' */*/*.m
perl -pi -w -e 's/= unique\(/= unique_bc\(/g;' */*/*.m
perl -pi -w -e 's/ = unique\(/ = unique_bc\(/g;' */*/*.m
perl -pi -w -e 's/ismember\(/ismember_bc\(/g;' */*/*.m
perl -pi -w -e 's/=ismember\(/=ismember_bc\(/g;' */*/*.m
perl -pi -w -e 's/= ismember\(/= ismember_bc\(/g;' */*/*.m
perl -pi -w -e 's/ = ismember\(/ = ismember_bc\(/g;' */*/*.m

perl -pi -w -e 's/union\(/union_bc\(/g;' */*/*/*.m
perl -pi -w -e 's/=union\(/=union_bc\(/g;' */*/*/*.m
perl -pi -w -e 's/= union\(/= union_bc\(/g;' */*/*/*.m
perl -pi -w -e 's/ = union\(/ = union_bc\(/g;' */*/*/*.m
perl -pi -w -e 's/intersect\(/intersect_bc\(/g;' */*/*/*.m
perl -pi -w -e 's/=intersect\(/=intersect_bc\(/g;' */*/*/*.m
perl -pi -w -e 's/= intersect\(/= intersect_bc\(/g;' */*/*/*.m
perl -pi -w -e 's/ = intersect\(/ = intersect_bc\(/g;' */*/*/*.m
perl -pi -w -e 's/setdiff\(/setdiff_bc\(/g;' */*/*/*.m
perl -pi -w -e 's/=setdiff\(/=setdiff_bc\(/g;' */*/*/*.m
perl -pi -w -e 's/= setdiff\(/= setdiff_bc\(/g;' */*/*/*.m
perl -pi -w -e 's/ = setdiff\(/ = setdiff_bc\(/g;' */*/*/*.m
perl -pi -w -e 's/unique\(/unique_bc\(/g;' */*/*/*.m
perl -pi -w -e 's/=unique\(/=unique_bc\(/g;' */*/*/*.m
perl -pi -w -e 's/= unique\(/= unique_bc\(/g;' */*/*/*.m
perl -pi -w -e 's/ = unique\(/ = unique_bc\(/g;' */*/*/*.m
perl -pi -w -e 's/ismember\(/ismember_bc\(/g;' */*/*/*.m
perl -pi -w -e 's/=ismember\(/=ismember_bc\(/g;' */*/*/*.m
perl -pi -w -e 's/= ismember\(/= ismember_bc\(/g;' */*/*/*.m
perl -pi -w -e 's/ = ismember\(/ = ismember_bc\(/g;' */*/*/*.m

perl -pi -w -e 's/union\(/union_bc\(/g;' */*/*/*/*.m
perl -pi -w -e 's/=union\(/=union_bc\(/g;' */*/*/*/*.m
perl -pi -w -e 's/= union\(/= union_bc\(/g;' */*/*/*/*.m
perl -pi -w -e 's/ = union\(/ = union_bc\(/g;' */*/*/*/*.m
perl -pi -w -e 's/intersect\(/intersect_bc\(/g;' */*/*/*/*.m
perl -pi -w -e 's/=intersect\(/=intersect_bc\(/g;' */*/*/*/*.m
perl -pi -w -e 's/= intersect\(/= intersect_bc\(/g;' */*/*/*/*.m
perl -pi -w -e 's/ = intersect\(/ = intersect_bc\(/g;' */*/*/*/*.m
perl -pi -w -e 's/setdiff\(/setdiff_bc\(/g;' */*/*/*/*.m
perl -pi -w -e 's/=setdiff\(/=setdiff_bc\(/g;' */*/*/*/*.m
perl -pi -w -e 's/= setdiff\(/= setdiff_bc\(/g;' */*/*/*/*.m
perl -pi -w -e 's/ = setdiff\(/ = setdiff_bc\(/g;' */*/*/*/*.m
perl -pi -w -e 's/unique\(/unique_bc\(/g;' */*/*/*/*.m
perl -pi -w -e 's/=unique\(/=unique_bc\(/g;' */*/*/*/*.m
perl -pi -w -e 's/= unique\(/= unique_bc\(/g;' */*/*/*/*.m
perl -pi -w -e 's/ = unique\(/ = unique_bc\(/g;' */*/*/*/*.m
perl -pi -w -e 's/ismember\(/ismember_bc\(/g;' */*/*/*/*.m
perl -pi -w -e 's/=ismember\(/=ismember_bc\(/g;' */*/*/*/*.m
perl -pi -w -e 's/= ismember\(/= ismember_bc\(/g;' */*/*/*/*.m
perl -pi -w -e 's/ = ismember\(/ = ismember_bc\(/g;' */*/*/*/*.m

perl -pi -w -e 's/union\(/union_bc\(/g;' */*/*/*/*/*.m
perl -pi -w -e 's/=union\(/=union_bc\(/g;' */*/*/*/*/*.m
perl -pi -w -e 's/= union\(/= union_bc\(/g;' */*/*/*/*/*.m
perl -pi -w -e 's/ = union\(/ = union_bc\(/g;' */*/*/*/*/*.m
perl -pi -w -e 's/intersect\(/intersect_bc\(/g;' */*/*/*/*/*.m
perl -pi -w -e 's/=intersect\(/=intersect_bc\(/g;' */*/*/*/*/*.m
perl -pi -w -e 's/= intersect\(/= intersect_bc\(/g;' */*/*/*/*/*.m
perl -pi -w -e 's/ = intersect\(/ = intersect_bc\(/g;' */*/*/*/*/*.m
perl -pi -w -e 's/setdiff\(/setdiff_bc\(/g;' */*/*/*/*/*.m
perl -pi -w -e 's/=setdiff\(/=setdiff_bc\(/g;' */*/*/*/*/*.m
perl -pi -w -e 's/= setdiff\(/= setdiff_bc\(/g;' */*/*/*/*/*.m
perl -pi -w -e 's/ = setdiff\(/ = setdiff_bc\(/g;' */*/*/*/*/*.m
perl -pi -w -e 's/unique\(/unique_bc\(/g;' */*/*/*/*/*.m
perl -pi -w -e 's/=unique\(/=unique_bc\(/g;' */*/*/*/*/*.m
perl -pi -w -e 's/= unique\(/= unique_bc\(/g;' */*/*/*/*/*.m
perl -pi -w -e 's/ = unique\(/ = unique_bc\(/g;' */*/*/*/*/*.m
perl -pi -w -e 's/ismember\(/ismember_bc\(/g;' */*/*/*/*/*.m
perl -pi -w -e 's/=ismember\(/=ismember_bc\(/g;' */*/*/*/*/*.m
perl -pi -w -e 's/= ismember\(/= ismember_bc\(/g;' */*/*/*/*/*.m
perl -pi -w -e 's/ = ismember\(/ = ismember_bc\(/g;' */*/*/*/*/*.m